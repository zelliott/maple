### URL

[http://custom-env-1.v8hharbp4m.us-west-1.elasticbeanstalk.com/](http://custom-env-1.v8hharbp4m.us-west-1.elasticbeanstalk.com/)

### Resource
 * [npm shrinkwrap](https://github.com/thewoolleyman/npm-shrinkwrap-helper)
 * [DocumentClient SDK](http://docs.aws.amazon.com/AWSJavaScriptSDK/latest/AWS/DynamoDB/DocumentClient.html)

### Passkeys

 * Test (0): 84f1ca25dac23fe851e1d418387ff902
 * Omar (1): 8e5a6bfc88f891ea799bc6694436edb9
 * Zack: (2): e4b07377c07d2c3d95a737e4bf642082
 * Spencer (3): ffe359d641982de20dbc86eae7ccb522
 * Zhi (4): 26ae945be740ffc1c6d7b2b88a0ec493
 * Nenkova (5): bd2979409b88ca2108d7464a74ddb38b
